import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ingredient_manager/features/ingredients/ingredient.dart';
import 'package:ingredient_manager/features/ingredients/ingredient_controller.dart';
import 'package:ingredient_manager/features/ingredients/ingredient_page.dart';
import 'package:ingredient_manager/features/ingredients/ingredient_repository.dart';

class MemoryRepository implements IngredientRepository {
  String? data;
  bool failLoad = false;
  bool failSave = false;
  Completer<void>? gate;
  @override
  Future<IngredientSnapshot?> load() async {
    if (failLoad) throw Exception('read failed');
    return data == null
        ? null
        : IngredientSnapshot.fromJson(
            jsonDecode(data!) as Map<String, dynamic>,
          );
  }

  @override
  Future<void> save(IngredientSnapshot snapshot) async {
    if (gate != null) await gate!.future;
    if (failSave) throw Exception('disk failed');
    data = jsonEncode(snapshot.toJson());
  }
}

void main() {
  test('CRUD, 공백 중복 검사, 체크 상태와 재시작 복원', () async {
    final repo = MemoryRepository();
    final c = IngredientController(repo);
    await c.initialize();
    expect(c.items.map((e) => e.name), ['소금', '당근', '설탕', '무']);
    expect(await c.add('대 파'), isNull);
    expect(await c.add('대\t파'), contains('이미'));
    expect(await c.add('대\u3000파'), contains('이미'));
    expect(await c.add(' \t '), isNotNull);
    expect(await c.add('양파'), isNull);
    final onion = c.items.last;
    expect(await c.rename(onion.id, '소 금'), contains('이미'));
    expect(await c.rename(onion.id, '감자'), isNull);
    expect(await c.select(onion.id, false), isNull);
    expect(await c.delete(c.items.first.id), isNull);
    final restarted = IngredientController(repo);
    await restarted.initialize();
    expect(restarted.items.any((e) => e.name == '소금'), isFalse);
    expect(restarted.items.last.name, '감자');
    expect(restarted.items.last.selected, isFalse);
    expect(restarted.selectedNames, ['대 파']);
  });

  test('새 기본 항목만 추가하고 사용자가 삭제한 항목은 복원하지 않음', () async {
    final repo = MemoryRepository();
    final c = IngredientController(repo);
    await c.initialize();
    await c.delete(c.items.first.id);
    await c.add('양 파');
    final next = IngredientController(
      repo,
      defaults: [...defaultIngredientNames, '양파', '후추'],
    );
    await next.initialize();
    expect(next.items.where((e) => ingredientKey(e.name) == '양파').length, 1);
    expect(next.items.any((e) => e.name == '소금'), isFalse);
    expect(next.items.last.name, '후추');
  });

  test('저장 실패 시 이전 데이터 유지, 재시도 가능', () async {
    final repo = MemoryRepository();
    final c = IngredientController(repo);
    await c.initialize();
    final old = repo.data;
    repo.failSave = true;
    expect(await c.add('감자'), contains('저장하지 못했어'));
    expect(c.items.length, 4);
    expect(repo.data, old);
    repo.failSave = false;
    expect(await c.add('감자'), isNull);
    expect(c.error, isNull);
  });

  test('읽기 실패 및 손상 데이터는 덮어쓰지 않음', () async {
    final repo = MemoryRepository()..data = '{broken';
    final c = IngredientController(repo);
    await c.initialize();
    expect(c.ready, isFalse);
    expect(repo.data, '{broken');
    expect(await c.add('감자'), isNotNull);
    repo.data = null;
    await c.initialize();
    expect(c.ready, isTrue);
  });

  test('저장 중 연속 요청은 거절하여 snapshot 유실 방지', () async {
    final repo = MemoryRepository();
    final c = IngredientController(repo);
    await c.initialize();
    repo.gate = Completer<void>();
    final first = c.add('감자');
    expect(await c.add('양파'), isNotNull);
    repo.gate!.complete();
    await first;
    expect(c.selectedNames, ['감자']);
  });

  testWidgets('입력 반복, 중복 안내, 체크, 수정과 삭제', (tester) async {
    final c = IngredientController(MemoryRepository());
    await tester.pumpWidget(MaterialApp(home: IngredientPage(controller: c)));
    await tester.pumpAndSettle();
    final input = find.byKey(const Key('ingredientInput'));
    for (final name in ['대파', '양파']) {
      await tester.enterText(input, name);
      await tester.tap(find.text('식재료 추가'));
      await tester.pumpAndSettle();
      expect(tester.widget<TextField>(input).controller!.text, isEmpty);
    }
    await tester.enterText(input, '대 파');
    await tester.tap(find.text('식재료 추가'));
    await tester.pumpAndSettle();
    expect(find.textContaining('이미 있는 식재료야'), findsOneWidget);
    expect(c.items.length, 6);
    await tester.ensureVisible(find.byTooltip('소금 관리'));
    await tester.tap(find.byTooltip('소금 관리'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('이름 수정'));
    await tester.pumpAndSettle();
    await tester.enterText(
      find.descendant(
        of: find.byType(AlertDialog),
        matching: find.byType(TextField),
      ),
      '후추',
    );
    await tester.tap(find.text('저장'));
    await tester.pumpAndSettle();
    expect(c.items.first.name, '후추');
    await tester.tap(find.byKey(ValueKey(c.items.first.id)));
    await tester.pumpAndSettle();
    expect(c.items.first.selected, isTrue);
    await tester.tap(find.byTooltip('후추 관리'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('항목 삭제'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('삭제'));
    await tester.pumpAndSettle();
    expect(c.items.any((e) => e.name == '후추'), isFalse);
    expect(tester.takeException(), isNull);
  });

  testWidgets('작은 화면과 큰 글꼴에서도 overflow가 없음', (tester) async {
    tester.view.physicalSize = const Size(320, 640);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(
      MaterialApp(
        builder: (context, child) => MediaQuery(
          data: MediaQuery.of(context)
              .copyWith(textScaler: const TextScaler.linear(2)),
          child: child!,
        ),
        home: IngredientPage(
          controller: IngredientController(MemoryRepository()),
        ),
      ),
    );
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
  });
}
