import 'package:flutter_test/flutter_test.dart';
import 'package:ingredient_manager/features/ingredients/ingredient_controller.dart';
import 'package:ingredient_manager/features/ingredients/ingredient_repository.dart';
import 'package:shared_preferences_platform_interface/in_memory_shared_preferences_async.dart';
import 'package:shared_preferences_platform_interface/shared_preferences_async_platform_interface.dart';

void main() {
  test('실제 LocalRepository의 직렬화·복원과 사용자별 저장 분리', () async {
    final original = SharedPreferencesAsyncPlatform.instance;
    SharedPreferencesAsyncPlatform.instance =
        InMemorySharedPreferencesAsync.empty();
    addTearDown(() => SharedPreferencesAsyncPlatform.instance = original);
    final a = IngredientController(LocalIngredientRepository(userId: 'user-a'));
    await a.initialize();
    await a.add('양파');
    await a.delete(a.items.first.id);
    final b = IngredientController(LocalIngredientRepository(userId: 'user-b'));
    await b.initialize();
    expect(b.selectedNames, isEmpty);
    expect(b.items.first.name, '소금');
    final restored = IngredientController(
      LocalIngredientRepository(userId: 'user-a'),
    );
    await restored.initialize();
    expect(restored.selectedNames, ['양파']);
    expect(restored.items.any((e) => e.name == '소금'), isFalse);
  });
}
