import 'package:flutter/material.dart';

import 'ingredient.dart';
import 'ingredient_controller.dart';

class IngredientPage extends StatefulWidget {
  const IngredientPage({super.key, required this.controller});
  final IngredientController controller;
  @override
  State<IngredientPage> createState() => _IngredientPageState();
}

class _IngredientPageState extends State<IngredientPage> {
  final _input = TextEditingController();
  final _focus = FocusNode();
  bool _selectedOnly = false;
  IngredientController get controller => widget.controller;

  @override
  void initState() {
    super.initState();
    controller.initialize();
  }

  @override
  void dispose() {
    _input.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _add() async {
    final result = await controller.add(_input.text);
    if (!mounted) return;
    if (result == null) {
      _input.clear();
      _focus.requestFocus();
    }
    _message(result ?? '식재료를 추가하고 저장했어.');
  }

  Future<void> _edit(Ingredient item) async {
    final result = await showDialog<String>(
      context: context,
      builder: (_) => _RenameDialog(controller: controller, item: item),
    );
    if (result != null) _message(result);
  }

  Future<void> _delete(Ingredient item) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('식재료를 삭제할까?'),
        content: Text('“${item.name}” 항목과 체크 상태를 목록에서 삭제해. 필요하면 다시 추가할 수 있어.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('취소'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('삭제'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    final result = await controller.delete(item.id);
    _message(result ?? '식재료를 삭제하고 저장했어.');
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: controller,
    builder: (context, _) {
      final visible = controller.items
          .where((e) => !_selectedOnly || e.selected)
          .toList();
      final enabled = controller.ready && !controller.busy;
      return Scaffold(
        appBar: AppBar(title: const Text('나의 식재료')),
        body: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 640),
              child: !controller.ready
                  ? Center(
                      child: controller.busy
                          ? const CircularProgressIndicator()
                          : Padding(
                              padding: const EdgeInsets.all(24),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(controller.error ?? '저장 데이터를 준비하고 있어.'),
                                  const SizedBox(height: 16),
                                  FilledButton(
                                    onPressed: controller.initialize,
                                    child: const Text('다시 시도'),
                                  ),
                                ],
                              ),
                            ),
                    )
                  : CustomScrollView(
                      slivers: [
                        SliverToBoxAdapter(
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Text(
                                  '가지고 있는 재료를 체크해 줘.',
                                  style: Theme.of(context).textTheme.titleLarge,
                                ),
                                const SizedBox(height: 8),
                                const Text(
                                  '체크된 재료를 레시피 추천에 사용할 수 있어.\n추가·수정·삭제와 체크 상태는 자동으로 저장돼.',
                                ),
                                const SizedBox(height: 24),
                                TextField(
                                  key: const Key('ingredientInput'),
                                  controller: _input,
                                  focusNode: _focus,
                                  enabled: enabled,
                                  maxLength: 50,
                                  textInputAction: TextInputAction.done,
                                  decoration: const InputDecoration(
                                    labelText: '식재료 직접 입력',
                                    hintText: '예: 양파, 감자 등을 한 번에 하나씩 입력해 줘.',
                                    border: OutlineInputBorder(),
                                  ),
                                  onSubmitted: (_) => _add(),
                                ),
                                FilledButton.icon(
                                  onPressed: enabled ? _add : null,
                                  icon: const Icon(Icons.add),
                                  label: const Text('식재료 추가'),
                                ),
                                const SizedBox(height: 16),
                                Wrap(
                                  spacing: 8,
                                  runSpacing: 8,
                                  children: [
                                    FilterChip(
                                      label: Text(
                                        '전체 ${controller.items.length}개',
                                      ),
                                      selected: !_selectedOnly,
                                      onSelected: (_) =>
                                          setState(() => _selectedOnly = false),
                                    ),
                                    FilterChip(
                                      label: Text(
                                        '보유 재료 ${controller.selectedNames.length}개',
                                      ),
                                      selected: _selectedOnly,
                                      onSelected: (_) =>
                                          setState(() => _selectedOnly = true),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                Semantics(
                                  liveRegion: true,
                                  child: Text(
                                    controller.busy
                                        ? '저장 중이야…'
                                        : controller.error ?? '기기에 저장됐어.',
                                    style: TextStyle(
                                      color: controller.error == null
                                          ? Theme.of(context)
                                                .colorScheme
                                                .primary
                                          : Theme.of(context).colorScheme.error,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        if (visible.isEmpty)
                          SliverToBoxAdapter(
                            child: Padding(
                              padding: const EdgeInsets.all(32),
                              child: Text(
                                _selectedOnly
                                    ? '체크한 재료가 없어. 전체 목록에서 재료를 체크해 줘.'
                                    : '아직 재료가 없어. 위에서 식재료를 추가해 줘.',
                              ),
                            ),
                          ),
                        SliverList.builder(
                          itemCount: visible.length,
                          itemBuilder: (context, index) {
                            final item = visible[index];
                            return Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 2,
                              ),
                              child: Card(
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: CheckboxListTile(
                                        key: ValueKey(item.id),
                                        value: item.selected,
                                        controlAffinity:
                                            ListTileControlAffinity.leading,
                                        title: Text(item.name),
                                        onChanged: enabled
                                            ? (value) async {
                                                final result = await controller
                                                    .select(
                                                      item.id,
                                                      value ?? false,
                                                    );
                                                if (result != null) {
                                                  _message(result);
                                                }
                                              }
                                            : null,
                                      ),
                                    ),
                                    PopupMenuButton<String>(
                                      enabled: enabled,
                                      tooltip: '${item.name} 관리',
                                      onSelected: (action) {
                                        if (action == 'edit') {
                                          _edit(item);
                                        } else {
                                          _delete(item);
                                        }
                                      },
                                      itemBuilder: (_) => const [
                                        PopupMenuItem(
                                          value: 'edit',
                                          child: Text('이름 수정'),
                                        ),
                                        PopupMenuItem(
                                          value: 'delete',
                                          child: Text('항목 삭제'),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                        const SliverToBoxAdapter(child: SizedBox(height: 32)),
                      ],
                    ),
            ),
          ),
        ),
      );
    },
  );
}

class _RenameDialog extends StatefulWidget {
  const _RenameDialog({required this.controller, required this.item});
  final IngredientController controller;
  final Ingredient item;
  @override
  State<_RenameDialog> createState() => _RenameDialogState();
}

class _RenameDialogState extends State<_RenameDialog> {
  late final _text = TextEditingController(text: widget.item.name);
  String? _error;
  bool _saving = false;
  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_saving) return;
    setState(() {
      _saving = true;
      _error = null;
    });
    final error = await widget.controller.rename(widget.item.id, _text.text);
    if (!mounted) return;
    if (error == null) {
      Navigator.pop(context, '식재료 이름을 수정하고 저장했어.');
    } else {
      setState(() {
        _saving = false;
        _error = error;
      });
    }
  }

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: !_saving,
    child: AlertDialog(
      title: const Text('식재료 이름 수정'),
      content: TextField(
        controller: _text,
        autofocus: true,
        enabled: !_saving,
        maxLength: 50,
        textInputAction: TextInputAction.done,
        decoration: InputDecoration(
          labelText: '식재료 이름',
          errorText: _error,
          errorMaxLines: 4,
        ),
        onSubmitted: (_) => _save(),
      ),
      actions: [
        TextButton(
          onPressed: _saving ? null : () => Navigator.pop(context),
          child: const Text('취소'),
        ),
        FilledButton(
          onPressed: _saving ? null : _save,
          child: Text(_saving ? '저장 중…' : '저장'),
        ),
      ],
    ),
  );
}
