import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'ingredient.dart';

/// 팀 DB가 확정되면 이 interface를 구현한 repository로 교체하면 돼.
/// 한 사용자에게 하나의 controller를 사용하고, save는 전체 snapshot을 저장해.
abstract interface class IngredientRepository {
  Future<IngredientSnapshot?> load();
  Future<void> save(IngredientSnapshot snapshot);
}

class LocalIngredientRepository implements IngredientRepository {
  LocalIngredientRepository({
    required String userId,
    SharedPreferencesAsync? preferences,
  }) : _preferences = preferences ?? SharedPreferencesAsync(),
       _key = 'ingredients.v1.${Uri.encodeComponent(userId)}' {
    if (userId.trim().isEmpty) throw ArgumentError.value(userId, 'userId');
  }
  final SharedPreferencesAsync _preferences;
  final String _key;

  @override
  Future<IngredientSnapshot?> load() async {
    final raw = await _preferences.getString(_key);
    if (raw == null) return null;
    return IngredientSnapshot.fromJson(jsonDecode(raw) as Map<String, dynamic>);
  }

  @override
  Future<void> save(IngredientSnapshot snapshot) =>
      _preferences.setString(_key, jsonEncode(snapshot.toJson()));
}
