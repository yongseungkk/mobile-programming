import 'package:flutter/foundation.dart';

import 'ingredient.dart';
import 'ingredient_repository.dart';

class IngredientController extends ChangeNotifier {
  IngredientController(
    this.repository, {
    this.defaults = defaultIngredientNames,
  });
  final IngredientRepository repository;
  final List<String> defaults;
  IngredientSnapshot _snapshot = IngredientSnapshot(
    items: [],
    seenDefaults: {},
  );
  bool busy = false;
  bool ready = false;
  String? error;
  bool _disposed = false;
  int _sequence = 0;

  List<Ingredient> get items => _snapshot.items;
  List<String> get selectedNames =>
      List.unmodifiable(items.where((e) => e.selected).map((e) => e.name));

  void _emit() {
    if (!_disposed) notifyListeners();
  }

  Future<void> initialize() async {
    if (busy || ready) return;
    busy = true;
    error = null;
    _emit();
    try {
      final stored = await repository.load();
      final next = [...?stored?.items];
      final seen = {...?stored?.seenDefaults};
      for (final name in defaults) {
        final key = ingredientKey(name);
        if (key.isEmpty || !seen.add(key)) continue;
        if (!next.any((e) => ingredientKey(e.name) == key)) {
          next.add(Ingredient(id: 'default:$key', name: displayName(name)));
        }
      }
      final merged = IngredientSnapshot(items: next, seenDefaults: seen);
      if (stored == null || seen.length != stored.seenDefaults.length) {
        await repository.save(merged);
      }
      _snapshot = merged;
      ready = true;
    } catch (_) {
      error = '재료를 불러오지 못했어. 저장된 데이터는 지우지 않았어. 다시 시도해 줘.';
    } finally {
      busy = false;
      _emit();
    }
  }

  String? _validate(String name, {String? excluding}) {
    final key = ingredientKey(name);
    if (key.isEmpty) return '식재료 이름을 입력해 줘.';
    if (name.runes.length > 50) return '식재료 이름은 50자 이내로 입력해 줘.';
    if (items.any((e) => e.id != excluding && ingredientKey(e.name) == key)) {
      return '이미 있는 식재료야. 띄어쓰기와 관계없이 같은 재료로 처리해.';
    }
    return null;
  }

  Future<String?> _commit(List<Ingredient> next) async {
    if (busy || !ready) return '저장 준비 중이야. 잠시 후 다시 시도해 줘.';
    busy = true;
    error = null;
    _emit();
    try {
      final candidate = IngredientSnapshot(
        items: next,
        seenDefaults: _snapshot.seenDefaults,
      );
      await repository.save(candidate);
      _snapshot = candidate;
      return null;
    } catch (_) {
      error = '저장하지 못했어. 변경 전 상태를 유지했으니 다시 시도해 줘.';
      return error;
    } finally {
      busy = false;
      _emit();
    }
  }

  /// null이면 저장 성공, 문자열이면 화면에 표시할 오류 메시지야.
  Future<String?> add(String input) async {
    final name = displayName(input);
    final validation = _validate(name);
    if (validation != null) return validation;
    return _commit([
      ...items,
      Ingredient(
        id: 'custom:${DateTime.now().microsecondsSinceEpoch}:${_sequence++}',
        name: name,
        selected: true,
      ),
    ]);
  }

  Future<String?> rename(String id, String input) async {
    if (!items.any((e) => e.id == id)) return '해당 식재료를 찾을 수 없어.';
    final name = displayName(input);
    final validation = _validate(name, excluding: id);
    if (validation != null) return validation;
    return _commit(
      items.map((e) => e.id == id ? e.copyWith(name: name) : e).toList(),
    );
  }

  Future<String?> select(String id, bool selected) async {
    if (!items.any((e) => e.id == id)) return '해당 식재료를 찾을 수 없어.';
    return _commit(
      items
          .map((e) => e.id == id ? e.copyWith(selected: selected) : e)
          .toList(),
    );
  }

  Future<String?> delete(String id) async {
    if (!items.any((e) => e.id == id)) return '해당 식재료를 찾을 수 없어.';
    return _commit(items.where((e) => e.id != id).toList());
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }
}
