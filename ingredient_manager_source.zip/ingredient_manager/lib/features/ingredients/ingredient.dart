/// 항목을 추가하려면 이 목록만 수정하면 돼. 기존 사용자의 목록에도 반영돼.
const defaultIngredientNames = ['소금', '당근', '설탕', '무'];

String ingredientKey(String name) => name
    .replaceAll(
      RegExp(
        r'[\s\u0085\u00a0\u1680\u2000-\u200b\u2028\u2029\u202f\u205f\u3000\ufeff]+',
      ),
      '',
    )
    .toLowerCase();

String displayName(String name) => name.trim().replaceAll(RegExp(r'\s+'), ' ');

class Ingredient {
  const Ingredient({
    required this.id,
    required this.name,
    this.selected = false,
  });
  final String id;
  final String name;
  final bool selected;

  Ingredient copyWith({String? name, bool? selected}) => Ingredient(
    id: id,
    name: name ?? this.name,
    selected: selected ?? this.selected,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'selected': selected,
  };

  factory Ingredient.fromJson(Map<String, dynamic> json) {
    if (json['id'] is! String ||
        (json['id'] as String).isEmpty ||
        json['name'] is! String ||
        ingredientKey(json['name'] as String).isEmpty ||
        json['selected'] is! bool) {
      throw const FormatException('잘못된 식재료 데이터');
    }
    return Ingredient(
      id: json['id'] as String,
      name: json['name'] as String,
      selected: json['selected'] as bool,
    );
  }
}

class IngredientSnapshot {
  IngredientSnapshot({
    required List<Ingredient> items,
    required Set<String> seenDefaults,
  }) : items = List.unmodifiable(items),
       seenDefaults = Set.unmodifiable(seenDefaults);
  final List<Ingredient> items;
  // 삭제한 기본 항목이 다음 실행에서 다시 생기지 않도록 기억해.
  final Set<String> seenDefaults;

  Map<String, dynamic> toJson() => {
    'version': 1,
    'items': items.map((e) => e.toJson()).toList(),
    'seenDefaults': seenDefaults.toList(),
  };

  factory IngredientSnapshot.fromJson(Map<String, dynamic> json) {
    if (json['version'] != 1 ||
        json['items'] is! List ||
        json['seenDefaults'] is! List) {
      throw const FormatException('지원하지 않는 저장 데이터');
    }
    final items = (json['items'] as List)
        .map((e) => Ingredient.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
    if (items.map((e) => e.id).toSet().length != items.length ||
        items.map((e) => ingredientKey(e.name)).toSet().length !=
            items.length) {
      throw const FormatException('중복된 저장 데이터');
    }
    return IngredientSnapshot(
      items: items,
      seenDefaults: (json['seenDefaults'] as List).cast<String>().toSet(),
    );
  }
}
