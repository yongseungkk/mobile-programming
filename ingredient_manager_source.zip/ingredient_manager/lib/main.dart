import 'package:flutter/material.dart';

import 'features/ingredients/ingredient_controller.dart';
import 'features/ingredients/ingredient_page.dart';
import 'features/ingredients/ingredient_repository.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const IngredientApp());
}

class IngredientApp extends StatefulWidget {
  const IngredientApp({super.key});
  @override
  State<IngredientApp> createState() => _IngredientAppState();
}

class _IngredientAppState extends State<IngredientApp> {
  // 팀 앱에서는 demo-local 대신 로그인한 사용자의 고유 ID를 전달해.
  late final _controller = IngredientController(
    LocalIngredientRepository(userId: 'demo-local'),
  );

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: '나의 식재료',
    theme: ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF356859)),
      useMaterial3: true,
    ),
    home: IngredientPage(controller: _controller),
  );
}
