# 용승 담당: 식재료 관리

Android용 Flutter 독립 실행 프로젝트야. 팀 앱의 식재료 관리 화면으로 옮겨 사용할 수 있어.

## 실행

Flutter 3.47.4 / Dart 3.13.3 환경에서 작성했어. Android Studio에서 이 폴더를 열고 Android 기기 또는 emulator를 선택한 다음 실행하면 돼.

```sh
flutter pub get
flutter run
```

`lib/main.dart`가 진입점이야. Android 실기기는 개발자 옵션과 USB debugging을 활성화해야 해.

## 사용 방법

1. 처음 실행하면 소금, 당근, 설탕, 무가 체크되지 않은 상태로 보여.
2. 현재 보유한 재료를 체크하면 자동 저장돼. 체크 해제는 항목을 삭제하지 않아.
3. 입력 칸에 재료 하나를 입력하고 `식재료 추가` 또는 키보드 완료를 누르면 체크된 항목으로 추가돼. 성공하면 입력 칸이 비워져서 계속 입력할 수 있어.
4. `대파`, `대 파`, ` 대   파 `는 같은 이름으로 판단해. 이미 있는 재료는 추가하지 않고 상태 메시지를 보여 줘. 영어 이름은 대소문자도 구분하지 않아. 동의어를 추론하지는 않아.
5. 항목 오른쪽 메뉴에서 이름을 수정하거나 삭제할 수 있어. 수정할 때도 중복을 검사하고, 삭제는 확인 창을 거쳐.
6. `보유 재료`를 누르면 체크된 항목만 조회할 수 있어. `전체`를 누르면 모든 항목이 보여.
7. 항목과 체크 상태는 변경할 때마다 기기에 저장돼. 저장 실패 시 이전 상태를 유지하고 입력값을 남겨 재시도할 수 있게 해.

## 자주 쓰는 재료 추가

`lib/features/ingredients/ingredient.dart`의 목록에 이름을 추가하면 돼.

```dart
const defaultIngredientNames = ['소금', '당근', '설탕', '무', '후추', '양파'];
```

앱을 재시작하면 새 기본 항목이 기존 사용자의 목록에도 체크되지 않은 상태로 추가돼. 이미 직접 입력한 같은 재료는 중복 생성하지 않아. 사용자가 삭제한 기본 재료는 다시 생기지 않아. 삭제한 재료가 다시 필요하면 입력 칸으로 추가하면 돼. 이 설정 목록에서 이름을 빼거나 바꾸는 것만으로 기존 사용자의 저장 항목을 삭제·수정하지는 않아.

## 파일 구조

| 파일 | 역할 |
| --- | --- |
| `lib/main.dart` | 독립 실행과 controller 생명 주기를 관리해. |
| `lib/features/ingredients/ingredient.dart` | 데이터 model, JSON 변환, 공백 중복 검사, 기본 목록을 정의해. |
| `lib/features/ingredients/ingredient_repository.dart` | 저장 interface와 사용자 ID별 로컬 저장을 구현해. |
| `lib/features/ingredients/ingredient_controller.dart` | CRUD, 체크 상태, 저장 성공·실패, 추천용 목록을 관리해. |
| `lib/features/ingredients/ingredient_page.dart` | 입력, checkbox 목록, 수정 dialog, 삭제 확인을 표시해. |
| `test/` | CRUD, 실패 복구, 화면 조작, 저장 adapter를 검증해. |

## 팀 프로젝트에 연결

`lib/features/ingredients/` 폴더를 팀 프로젝트로 복사하고 `shared_preferences` dependency를 추가해. 팀 프로젝트의 Dart/Flutter 버전이 이 프로젝트보다 낮으면 SDK와 package 호환성을 먼저 맞춰 줘.

도원 담당 로그인에서 얻은 실제 UID로 repository와 controller를 한 번 만들고 같은 인스턴스를 관련 화면에 전달하면 돼.

```dart
final ingredients = IngredientController(
  LocalIngredientRepository(userId: signedInUserId),
);
await ingredients.initialize();

// 팀 앱의 탭 또는 route에서 표시해.
IngredientPage(key: ValueKey(signedInUserId), controller: ingredients);
```

`demo-local`은 독립 실행용 ID야. 팀 앱에서 그대로 사용하면 모든 로그인 사용자가 같은 데이터를 보게 되므로 실제 UID로 교체해. 계정이 바뀌면 기존 화면과 controller를 dispose하고 새 UID로 다시 생성해. 추천 화면과 관리 화면은 같은 controller를 공유해. 한 UID에 여러 controller를 만들어 동시에 저장하지 않아야 해.

찬범 담당 추천 기능에는 `ingredients.selectedNames`를 전달하면 돼.

```dart
if (ingredients.ready && !ingredients.busy) {
  final List<String> ingredientNames = ingredients.selectedNames;
  // ingredientNames와 경환 담당 설문 정보를 추천 service에 전달해.
}
```

이 목록에는 저장 성공한 체크 항목만 들어가. 빈 목록이면 추천 화면에서 재료 선택 안내를 표시하면 돼. 자동 화면 갱신은 `ListenableBuilder(listenable: ingredients, ...)`로 연결할 수 있어.

현재는 `SharedPreferencesAsync`에 JSON을 저장하는 **기기 로컬 저장**이야. 서버 DB 연결이나 다른 기기와의 동기화는 포함되지 않았어. 팀 DB 종류·접속 설정·인증 코드가 제공되지 않았기 때문이야. 팀 DB가 정해지면 `IngredientRepository`의 `load()`와 `save()`를 구현하고 주입 부분만 바꾸면 돼. 서버 구현에서도 UID별 권한 검사, 전체 snapshot 저장의 원자성, 다중 기기 충돌 정책은 별도로 적용해야 해.

JSON snapshot에는 version, items(id/name/selected), seenDefaults가 들어가. seenDefaults는 삭제한 기본 재료가 재생성되는 것을 막는 이력이므로 DB로 옮길 때도 같이 저장해야 해. 로컬 저장 키는 `ingredients.v1.<URI-encoded UID>`야. 앱 데이터 삭제·앱 삭제에는 이 데이터가 유지되지 않을 수 있어.

## 강의 내용과 연결

제공된 PDF는 이미지 기반이어서 OCR과 페이지 이미지로 확인했어. 주요 구현 근거는 다음과 같아.

- Dart Foundations / Logic / Structuring의 type, List, 조건문, class, exception을 model과 검증에 적용했어.
- Flutter Widgets / Styling / Layout의 widget 구성과 스크롤 layout을 화면에 적용했어.
- Input 7~10쪽의 TextEditingController와 onSubmitted를 반복 입력에 적용했어.
- State 48~49쪽의 ChangeNotifier와 notifyListeners를 상태 공유에 적용했어. 화면 구독은 내장 ListenableBuilder를 사용했어.
- Persistence 8~15쪽의 기기 저장과 shared_preferences를 작은 재료 목록 저장에 적용했어.
- Async의 await·실패 처리와 Repository 분리를 저장 로직에 적용했어.
- Architecture 17~21쪽의 View / Logic / Model 분리를 파일 구조에 적용했어.
- Navigation, Packages, Themes도 참고했지만 다른 팀원의 화면이나 공통 디자인 체계는 구현 범위에 넣지 않았어.

강의의 기존 SharedPreferences 예제 대신, package 공식 문서에서 새 구현에 권장하는 SharedPreferencesAsync를 사용했어. 따라서 이 코드의 read/write는 모두 await해.
공식 문서: https://pub.dev/packages/shared_preferences

촬영·이미지 인식, 로그인, 설문, LLM 호출, 추천 화면, 커뮤니티는 이 모듈에 포함되지 않아. 이번 결과물은 용승 담당 식재료 관리 기능이야.

## 검증

```sh
flutter analyze
flutter test
flutter build apk --debug
```

테스트는 공백 중복, 반복 추가, 수정 중복, 체크, 삭제, 재생성 후 복원, 기본 항목 확장, 저장 실패, 데이터 손상, 동시 저장 방지, 작은 화면·큰 글꼴, 사용자별 저장 분리를 포함해. 저장 adapter 테스트는 platform storage를 메모리 구현으로 대체하므로 실제 Android 디스크를 검증하는 테스트는 아니야.

현재 Mac의 Flutter 전역 설정이 이미 사라진 JDK 경로를 가리켜서 APK build는 Android Studio의 JDK로 직접 Gradle을 실행했어. 전역 설정은 변경하지 않았어. 같은 문제가 발생하면 Android Studio의 Gradle JDK를 유효한 JDK로 지정하거나 아래 명령을 사용하면 돼.

```sh
cd android
JAVA_HOME='/Applications/Android Studio.app/Contents/jbr/Contents/Home' ./gradlew assembleDebug
```

배포용 서명은 구성하지 않았어. 제공하는 APK는 팀 개발·확인용 debug build야.

최종 확인 결과는 `flutter analyze` 문제 없음, 자동 테스트 8개 통과, Gradle `assembleDebug` 성공이야. 연결된 Android 실기기나 emulator가 없어서 기기에서 앱을 실행하고 강제 종료한 뒤 저장을 복원하는 검증은 아직 하지 못했어.
