package com.teamrecipe.ingredient_manager

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
