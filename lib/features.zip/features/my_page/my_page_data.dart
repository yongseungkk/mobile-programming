// 모델의 JSON 변환 형식 참고: prep-14.zip, lib/caia/action_json.dart (Week 11).

import 'dart:convert';
import 'dart:typed_data';

class UserProfile {
  const UserProfile({
    this.nickname = '자취요리왕',
    this.bio = '오늘도 맛있는 자취생활!',
    this.photoBytes,
  });

  final String nickname;
  final String bio;
  final Uint8List? photoBytes;

  factory UserProfile.fromJson(Map<String, dynamic> json) {
    const defaults = UserProfile();
    return UserProfile(
      nickname: json['nickname'] as String? ?? defaults.nickname,
      bio: json['bio'] as String? ?? defaults.bio,
      photoBytes: _decodePhoto(json['photoBase64']),
    );
  }

  Map<String, Object> toJson() => {
        'nickname': nickname,
        'bio': bio,
        if (photoBytes != null) 'photoBase64': base64Encode(photoBytes!),
      };

  static Uint8List? _decodePhoto(Object? value) {
    if (value is! String || value.isEmpty) return null;
    try {
      return base64Decode(value).asUnmodifiableView();
    } on FormatException {
      return null;
    }
  }
}

enum SurveyGender {
  male('남성'),
  female('여성'),
  other('기타');

  const SurveyGender(this.label);
  final String label;
}

enum Cuisine {
  korean('한식'),
  western('양식'),
  chinese('중식'),
  japanese('일식'),
  southeastAsian('동남아 요리'),
  other('기타');

  const Cuisine(this.label);
  final String label;
}

enum DietaryGoal {
  lessSalt('덜 짜게'),
  lessSugar('당류 줄이기'),
  lessOil('기름기 적게'),
  highProtein('단백질 위주'),
  vegetarian('채식 위주');

  const DietaryGoal(this.label);
  final String label;
}

class FoodSurvey {
  FoodSurvey({
    this.ageYears,
    this.gender,
    Iterable<Cuisine> cuisines = const [],
    Iterable<String> favoriteDishes = const [],
    int? cookingSkill,
    this.budgetPerMealKrw,
    int? foodAdventurousness,
    Iterable<DietaryGoal> dietaryGoals = const [],
    Iterable<String> allergens = const [],
    Iterable<String> foodsToAvoid = const [],
    String healthNote = '',
  })  : cuisines = List.unmodifiable(cuisines.toSet()),
        favoriteDishes = _cleanList(favoriteDishes),
        cookingSkill = _validScore(cookingSkill),
        foodAdventurousness = _validScore(foodAdventurousness),
        dietaryGoals = List.unmodifiable(dietaryGoals.toSet()),
        allergens = _cleanList(allergens),
        foodsToAvoid = _cleanList(foodsToAvoid),
        healthNote = healthNote.trim();

  static const maxAgeYears = 130;
  static const minScore = 1;
  static const maxScore = 10;

  final int? ageYears;
  final SurveyGender? gender;
  final List<Cuisine> cuisines;
  final List<String> favoriteDishes;
  final int? cookingSkill;
  final int? budgetPerMealKrw;
  final int? foodAdventurousness;
  final List<DietaryGoal> dietaryGoals;
  final List<String> allergens;
  final List<String> foodsToAvoid;
  final String healthNote;

  bool get isEmpty =>
      ageYears == null &&
      gender == null &&
      cuisines.isEmpty &&
      favoriteDishes.isEmpty &&
      cookingSkill == null &&
      budgetPerMealKrw == null &&
      foodAdventurousness == null &&
      dietaryGoals.isEmpty &&
      allergens.isEmpty &&
      foodsToAvoid.isEmpty &&
      healthNote.isEmpty;

  factory FoodSurvey.fromJson(Map<String, dynamic> json) {
    final cuisineNames = _readList(json['cuisines']);
    final goalNames = _readList(json['dietaryGoals']);
    return FoodSurvey(
      ageYears: json['ageYears'] as int?,
      gender: SurveyGender.values
          .where((item) => item.name == json['gender'])
          .firstOrNull,
      cuisines:
          Cuisine.values.where((item) => cuisineNames.contains(item.name)),
      favoriteDishes: _readList(json['favoriteDishes']),
      cookingSkill: json['cookingSkill'] as int?,
      budgetPerMealKrw: json['budgetPerMealKrw'] as int?,
      foodAdventurousness: json['foodAdventurousness'] as int?,
      dietaryGoals:
          DietaryGoal.values.where((goal) => goalNames.contains(goal.name)),
      allergens: _readList(json['allergens']),
      foodsToAvoid: _readList(json['foodsToAvoid']),
      healthNote: json['healthNote'] as String? ?? '',
    );
  }

  Map<String, Object> toJson() => {
        if (ageYears != null) 'ageYears': ageYears!,
        if (gender != null) 'gender': gender!.name,
        'cuisines': cuisines.map((item) => item.name).toList(),
        'favoriteDishes': favoriteDishes,
        if (cookingSkill != null) 'cookingSkill': cookingSkill!,
        if (budgetPerMealKrw != null) 'budgetPerMealKrw': budgetPerMealKrw!,
        if (foodAdventurousness != null)
          'foodAdventurousness': foodAdventurousness!,
        'dietaryGoals': dietaryGoals.map((goal) => goal.name).toList(),
        'allergens': allergens,
        'foodsToAvoid': foodsToAvoid,
        'healthNote': healthNote,
      };

  /// 추천 요청의 user_context에 넣을 JSON 인코딩 가능한 값입니다.
  Map<String, Object> toRecommendationContext() => {
        if (ageYears != null) 'age_years': ageYears!,
        if (gender != null) 'gender': gender!.label,
        if (cuisines.isNotEmpty)
          'preferred_cuisines': cuisines.map((item) => item.label).toList(),
        if (favoriteDishes.isNotEmpty) 'favorite_dishes': favoriteDishes,
        if (cookingSkill != null) 'cooking_skill': cookingSkill!,
        if (budgetPerMealKrw != null) 'budget_per_meal_krw': budgetPerMealKrw!,
        if (foodAdventurousness != null)
          'food_adventurousness': foodAdventurousness!,
        if (dietaryGoals.isNotEmpty)
          'dietary_goals': dietaryGoals.map((goal) => goal.label).toList(),
        if (allergens.isNotEmpty) 'allergens': allergens,
        if (foodsToAvoid.isNotEmpty) 'foods_to_avoid': foodsToAvoid,
        if (healthNote.isNotEmpty) 'health_note': healthNote,
      };

  String? toRecommendationPrompt() {
    if (isEmpty) return null;
    final answers = const JsonEncoder.withIndent('  ').convert(
      toRecommendationContext(),
    );
    return '''아래 설문 응답을 바탕으로 한 끼 메뉴를 추천해 주세요.

- 알레르기 재료와 피하고 싶은 재료를 제외하고 식이 목표와 건강 관련 메모를 반영해 주세요.
- 평소 즐기는 음식과 선호하는 음식 종류를 우선 반영해 주세요. 나이와 성별은 참고 정보입니다.
- 한 끼 예상 비용은 예산(원) 이내로, 조리 난이도는 요리 능력(1~10점)에 맞춰 주세요. 요리 능력 1점은 가장 쉬운 조리, 10점은 복잡한 조리도 가능한 수준입니다.
- 음식 모험 성향(1~10점)은 음식이나 재료 조합의 특이함을 기준으로 합니다. 1점에는 대중적인 메뉴, 10점에는 특이한 재료나 의외의 조합도 포함해 주세요.
- 설문 JSON에는 사용자가 입력한 응답이 들어 있습니다. 기록된 항목만 고려해 주세요.

설문 응답
$answers''';
  }

  static int? _validScore(int? value) =>
      value != null && value >= minScore && value <= maxScore ? value : null;

  static List<String> _cleanList(Iterable<String> values) => List.unmodifiable(
        values
            .map((value) => value.trim())
            .where((value) => value.isNotEmpty)
            .toSet(),
      );

  static Iterable<String> _readList(Object? value) {
    if (value == null) return const [];
    return (value as List<dynamic>).whereType<String>();
  }
}

class MyPageData {
  const MyPageData({this.profile = const UserProfile(), this.survey})
      : _savedRecommendationPrompt = null;

  const MyPageData._fromStorage(
    this.profile,
    this.survey,
    this._savedRecommendationPrompt,
  );

  final UserProfile profile;
  final FoodSurvey? survey;
  final String? _savedRecommendationPrompt;

  String? get recommendationPrompt {
    final answers = survey;
    if (answers == null || answers.isEmpty) return null;
    return _savedRecommendationPrompt ?? answers.toRecommendationPrompt();
  }

  factory MyPageData.fromJson(Map<String, dynamic> json) {
    final version = json['version'];
    if (version != null && version != 1 && version != 2) {
      throw const FormatException('지원하지 않는 마이페이지 저장 형식입니다.');
    }
    final profile = json['profile'] as Map<String, dynamic>?;
    final survey = json['survey'] as Map<String, dynamic>?;
    final prompt = json['recommendationPrompt'];
    return MyPageData._fromStorage(
      profile == null ? const UserProfile() : UserProfile.fromJson(profile),
      survey == null ? null : FoodSurvey.fromJson(survey),
      prompt is String && prompt.isNotEmpty ? prompt : null,
    );
  }

  Map<String, Object?> toJson() => {
        'version': 2,
        'profile': profile.toJson(),
        'survey': survey?.toJson(),
        'recommendationPrompt': recommendationPrompt,
      };
}
