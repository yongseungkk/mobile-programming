import 'dart:convert';

import 'package:flutter/foundation.dart';
// shared_preferences의 SharedPreferencesAsync 사용.
// 출처: https://pub.dev/packages/shared_preferences/versions/2.3.3
import 'package:shared_preferences/shared_preferences.dart';

import 'my_page_data.dart';
import 'my_page_file_storage_stub.dart'
    if (dart.library.io) 'my_page_file_storage.dart' as file_storage;

/// 팀 DB가 정해지면 이 인터페이스를 구현해 화면에 연결합니다.
abstract interface class MyPageRepository {
  Future<MyPageData> load();
  Future<void> save(MyPageData data);
}

class LocalMyPageRepository implements MyPageRepository {
  LocalMyPageRepository({this.storageKey = 'jachwi_hanki.my_page'})
      : _preferences = SharedPreferencesAsync();

  final String storageKey;
  final SharedPreferencesAsync _preferences;

  @override
  Future<MyPageData> load() async {
    // 기존 설치에서 저장한 설문과 프로필도 읽습니다.
    final value = (kIsWeb ? null : await file_storage.read(storageKey)) ??
        await _preferences.getString(storageKey);
    if (value == null) return const MyPageData();
    return MyPageData.fromJson(jsonDecode(value) as Map<String, dynamic>);
  }

  @override
  Future<void> save(MyPageData data) {
    final snapshot = jsonEncode(data.toJson());
    if (kIsWeb) return _preferences.setString(storageKey, snapshot);
    return file_storage.write(storageKey, snapshot);
  }
}

/// 메뉴를 추천할 때마다 호출해 최신 저장 답변을 읽습니다.
Future<Map<String, Object>> loadRecommendationUserContext(
  MyPageRepository repository,
) async {
  final saved = await repository.load();
  return saved.survey?.toRecommendationContext() ?? const {};
}

/// 저장한 설문 프롬프트를 읽습니다. 응답이 없거나 지웠다면 null입니다.
Future<String?> loadRecommendationPrompt(MyPageRepository repository) async {
  final saved = await repository.load();
  return saved.recommendationPrompt;
}
