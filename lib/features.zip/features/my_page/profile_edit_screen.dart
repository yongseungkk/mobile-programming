import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/material.dart';

import 'my_page_data.dart';
import 'my_page_widgets.dart';
import 'profile_photo.dart';

class ProfileEditScreen extends StatefulWidget {
  const ProfileEditScreen({
    super.key,
    required this.initial,
    required this.onSave,
    this.recoveredPhoto,
  });

  final UserProfile initial;
  final Future<void> Function(UserProfile) onSave;
  final Future<Uint8List?>? recoveredPhoto;

  @override
  State<ProfileEditScreen> createState() => _ProfileEditScreenState();
}

class _ProfileEditScreenState extends State<ProfileEditScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nickname;
  late final TextEditingController _bio;
  Uint8List? _photoBytes;
  bool _pickingPhoto = false;
  bool _saving = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _nickname = TextEditingController(text: widget.initial.nickname);
    _bio = TextEditingController(text: widget.initial.bio);
    _photoBytes = widget.initial.photoBytes;
    final recovered = widget.recoveredPhoto;
    if (recovered != null) unawaited(_selectPhoto(() => recovered));
  }

  @override
  void dispose() {
    _nickname.dispose();
    _bio.dispose();
    super.dispose();
  }

  Future<void> _selectPhoto(Future<Uint8List?> Function() select) async {
    setState(() {
      _pickingPhoto = true;
      _error = null;
    });
    try {
      final photo = await select();
      if (photo != null && mounted) setState(() => _photoBytes = photo);
    } catch (_) {
      if (mounted) {
        setState(() => _error = '이 사진을 열 수 없어요. 다른 사진을 선택해 주세요.');
      }
    } finally {
      if (mounted) setState(() => _pickingPhoto = false);
    }
  }

  Future<void> _save() async {
    if (_saving || _pickingPhoto || !_formKey.currentState!.validate()) return;
    FocusScope.of(context).unfocus();
    setState(() {
      _saving = true;
      _error = null;
    });
    try {
      await widget.onSave(
        UserProfile(
          nickname: _nickname.text.trim(),
          bio: _bio.text.trim(),
          photoBytes: _photoBytes,
        ),
      );
      if (mounted) Navigator.of(context).pop('프로필을 저장했어요.');
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _saving = false;
        _error = '프로필을 저장하지 못했어요. 다시 시도해 주세요.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final busy = _pickingPhoto || _saving;
    return MyPageEditor(
      title: '프로필 수정',
      saveLabel: '프로필 저장',
      saving: _saving,
      error: _error,
      onSave: _pickingPhoto ? null : _save,
      body: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            MyPagePanel(
              child: Column(
                children: [
                  MyPageAvatar(photoBytes: _photoBytes, size: 94),
                  const SizedBox(height: 15),
                  const MyPageSectionTitle('프로필 사진'),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 6,
                    runSpacing: 4,
                    alignment: WrapAlignment.center,
                    children: [
                      OutlinedButton.icon(
                        icon: const Icon(Icons.add_photo_alternate_outlined),
                        label: Text(_pickingPhoto ? '불러오는 중…' : '사진 선택'),
                        onPressed:
                            busy ? null : () => _selectPhoto(pickProfilePhoto),
                      ),
                      if (_photoBytes != null)
                        TextButton(
                          onPressed: busy
                              ? null
                              : () => setState(() {
                                    _photoBytes = null;
                                    _error = null;
                                  }),
                          child: const Text('사진 제거'),
                        ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            MyPagePanel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  TextFormField(
                    controller: _nickname,
                    enabled: !_saving,
                    maxLength: 16,
                    textInputAction: TextInputAction.next,
                    decoration: const InputDecoration(labelText: '닉네임'),
                    validator: (value) => value == null || value.trim().isEmpty
                        ? '닉네임을 입력해 주세요.'
                        : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _bio,
                    enabled: !_saving,
                    maxLength: 60,
                    maxLines: 2,
                    decoration: const InputDecoration(labelText: '한 줄 소개 (선택)'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
