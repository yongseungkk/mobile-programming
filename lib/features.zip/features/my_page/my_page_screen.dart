import 'dart:typed_data';

import 'package:flutter/material.dart';

import 'food_survey_screen.dart';
import 'my_page_controller.dart';
import 'my_page_data.dart';
import 'my_page_widgets.dart';
import 'profile_edit_screen.dart';
import 'profile_photo.dart';

/// 팀의 레시피와 요리 기록에서 받은 수를 표시합니다.
class MyPageStats {
  const MyPageStats({this.savedRecipes, this.writtenRecipes, this.cookedMeals});

  final int? savedRecipes;
  final int? writtenRecipes;
  final int? cookedMeals;
}

class MyPageScreen extends StatefulWidget {
  const MyPageScreen({
    super.key,
    required this.controller,
    this.stats = const MyPageStats(),
    this.onOpenSettings,
  });

  final MyPageController controller;
  final MyPageStats stats;
  final VoidCallback? onOpenSettings;

  @override
  State<MyPageScreen> createState() => _MyPageScreenState();
}

class _MyPageScreenState extends State<MyPageScreen> {
  Future<Uint8List?>? _recoveredPhoto;

  @override
  void initState() {
    super.initState();
    _recoveredPhoto = recoverProfilePhoto();
  }

  Future<void> _openProfile(BuildContext context, UserProfile profile) {
    final recoveredPhoto = _recoveredPhoto;
    _recoveredPhoto = null;
    return _openEditor(
      context,
      ProfileEditScreen(
        initial: profile,
        onSave: widget.controller.saveProfile,
        recoveredPhoto: recoveredPhoto,
      ),
    );
  }

  // 화면 열기와 저장 결과 받기: prep-14.zip, lib/caia/action_result.dart (Week 8) 참고.
  Future<void> _openEditor(BuildContext context, Widget editor) async {
    final messenger = ScaffoldMessenger.of(context);
    messenger.removeCurrentSnackBar();
    final message = await Navigator.of(context).push<String>(
      MaterialPageRoute(builder: (_) => editor),
    );
    if (message == null || !context.mounted) return;
    messenger.showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final controller = widget.controller;
    final stats = widget.stats;
    final onOpenSettings = widget.onOpenSettings;
    return Scaffold(
      backgroundColor: MyPageColors.background,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: MyPageColors.background,
        foregroundColor: MyPageColors.ink,
        centerTitle: false,
        toolbarHeight: 66,
        titleSpacing: 20,
        scrolledUnderElevation: 0,
        title: const Text(
          '마이페이지',
          style: TextStyle(
              fontSize: 24, fontWeight: FontWeight.w700, letterSpacing: -.7),
        ),
        actions: [
          if (onOpenSettings != null)
            Padding(
              padding: const EdgeInsets.only(right: 10),
              child: IconButton(
                onPressed: onOpenSettings,
                tooltip: '설정',
                icon: const Icon(Icons.settings_outlined),
              ),
            ),
        ],
      ),
      body: SafeArea(
        top: false,
        child: ListenableBuilder(
          listenable: controller,
          builder: (context, _) {
            final data = controller.data;
            if (data == null) {
              return Center(
                child: controller.loadError == null
                    ? const CircularProgressIndicator()
                    : Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Text('마이페이지를 불러오지 못했어요.'),
                          TextButton(
                            onPressed: controller.load,
                            child: const Text('다시 시도'),
                          ),
                        ],
                      ),
              );
            }
            final survey = data.survey;
            final hasAnswers = survey != null && !survey.isEmpty;
            return Align(
              alignment: Alignment.topCenter,
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 540),
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(20, 13, 20, 28),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _ProfileHeader(
                        profile: data.profile,
                        onEdit: () => _openProfile(context, data.profile),
                      ),
                      const SizedBox(height: 24),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                              child: _StatTile('저장한 레시피', stats.savedRecipes)),
                          const SizedBox(width: 8),
                          Expanded(
                              child:
                                  _StatTile('작성한 레시피', stats.writtenRecipes)),
                          const SizedBox(width: 8),
                          Expanded(
                              child: _StatTile('요리한 메뉴', stats.cookedMeals)),
                        ],
                      ),
                      const SizedBox(height: 28),
                      const MyPageSectionTitle('맞춤 메뉴 추천'),
                      const SizedBox(height: 11),
                      _SurveyCard(
                        hasAnswers: hasAnswers,
                        onOpen: () => _openEditor(
                          context,
                          FoodSurveyScreen(
                              initial: survey, onSave: controller.saveSurvey),
                        ),
                      ),
                      const SizedBox(height: 12),
                      _RecommendationTile(
                        hasAnswers: hasAnswers,
                        onOpen: () => showModalBottomSheet<void>(
                          context: context,
                          useSafeArea: true,
                          isScrollControlled: true,
                          showDragHandle: true,
                          backgroundColor: MyPageColors.card,
                          constraints: const BoxConstraints(maxWidth: 540),
                          builder: (_) => _RecommendationSheet(
                            answers:
                                survey?.toRecommendationContext() ?? const {},
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class _ProfileHeader extends StatelessWidget {
  const _ProfileHeader({required this.profile, required this.onEdit});

  final UserProfile profile;
  final VoidCallback onEdit;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        DecoratedBox(
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: MyPageColors.card,
            border: Border.all(color: MyPageColors.line),
          ),
          child: Padding(
            padding: const EdgeInsets.all(4),
            child: MyPageAvatar(photoBytes: profile.photoBytes, size: 86),
          ),
        ),
        const SizedBox(height: 12),
        Text(
          profile.nickname,
          textAlign: TextAlign.center,
          style: const TextStyle(
            color: MyPageColors.ink,
            fontSize: 23,
            fontWeight: FontWeight.w700,
            letterSpacing: -.65,
          ),
        ),
        if (profile.bio.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(
              profile.bio,
              textAlign: TextAlign.center,
              style: const TextStyle(color: MyPageColors.muted, height: 1.45),
            ),
          ),
        const SizedBox(height: 9),
        OutlinedButton.icon(
          onPressed: onEdit,
          style: OutlinedButton.styleFrom(
            backgroundColor: MyPageColors.card,
            foregroundColor: MyPageColors.ink,
            side: const BorderSide(color: MyPageColors.line),
            padding: const EdgeInsets.symmetric(horizontal: 15),
            minimumSize: const Size(0, 38),
          ),
          icon: const Icon(Icons.edit_outlined, size: 16),
          label: const Text('프로필 수정'),
        ),
      ],
    );
  }
}

class _StatTile extends StatelessWidget {
  const _StatTile(this.label, this.value);

  final String label;
  final int? value;

  @override
  Widget build(BuildContext context) {
    return MyPagePanel(
      padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 5),
      child: Column(
        children: [
          Text(
            label,
            textAlign: TextAlign.center,
            style: const TextStyle(color: MyPageColors.muted, fontSize: 12),
          ),
          const SizedBox(height: 4),
          Text(
            value?.toString() ?? '—',
            semanticsLabel: value == null ? '기록 연동 전' : null,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: MyPageColors.ink,
              fontSize: 19,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

class _SurveyCard extends StatelessWidget {
  const _SurveyCard({required this.hasAnswers, required this.onOpen});

  final bool hasAnswers;
  final VoidCallback onOpen;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: MyPageColors.peach,
        borderRadius: BorderRadius.circular(21),
        border: Border.all(color: const Color(0xFFF1D7C2)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(17),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const MyPageSectionTitle('추천 설문'),
                      const SizedBox(height: 5),
                      Text(
                        hasAnswers
                            ? '저장한 음식 취향과 식이 조건을 수정할 수 있어요.'
                            : '나이, 선호 음식과 식이 조건을 메뉴 추천에 반영해요.',
                        style: const TextStyle(
                          color: MyPageColors.muted,
                          fontSize: 14,
                          height: 1.45,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 13),
                DecoratedBox(
                  decoration: BoxDecoration(
                    color: const Color(0xFFF4D4BA),
                    borderRadius: BorderRadius.circular(17),
                  ),
                  child: const SizedBox.square(
                    dimension: 60,
                    child: Icon(
                      Icons.soup_kitchen_outlined,
                      size: 32,
                      color: MyPageColors.accent,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: onOpen,
              style: FilledButton.styleFrom(
                backgroundColor: MyPageColors.accent,
                foregroundColor: Colors.white,
                minimumSize: const Size(0, 43),
                padding: const EdgeInsets.fromLTRB(15, 0, 12, 0),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(hasAnswers ? '설문 수정' : '설문 시작'),
                  const SizedBox(width: 7),
                  const Icon(Icons.arrow_forward_rounded, size: 17),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RecommendationTile extends StatelessWidget {
  const _RecommendationTile({required this.hasAnswers, required this.onOpen});

  final bool hasAnswers;
  final VoidCallback onOpen;

  @override
  Widget build(BuildContext context) {
    final border = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(18),
      side: const BorderSide(color: MyPageColors.line),
    );
    return Material(
      shape: border,
      color: MyPageColors.card,
      clipBehavior: Clip.antiAlias,
      child: ListTile(
        onTap: onOpen,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 3),
        leading: DecoratedBox(
          decoration: BoxDecoration(
            color: const Color(0xFFF5EDE1),
            borderRadius: BorderRadius.circular(11),
          ),
          child: const SizedBox.square(
            dimension: 40,
            child: Icon(
              Icons.assignment_outlined,
              color: MyPageColors.accent,
              size: 21,
            ),
          ),
        ),
        title: const Text(
          '추천에 쓰이는 정보',
          style:
              TextStyle(color: MyPageColors.ink, fontWeight: FontWeight.w700),
        ),
        subtitle: Text(
          hasAnswers ? '저장한 답변을 확인할 수 있어요.' : '설문을 저장하면 여기에 답변이 표시돼요.',
          style: const TextStyle(color: MyPageColors.muted, fontSize: 13),
        ),
        trailing:
            const Icon(Icons.chevron_right_rounded, color: MyPageColors.muted),
      ),
    );
  }
}

class _RecommendationSheet extends StatelessWidget {
  const _RecommendationSheet({required this.answers});

  final Map<String, Object> answers;

  static const _labels = {
    'age_years': '만 나이',
    'gender': '성별',
    'preferred_cuisines': '선호하는 음식 종류',
    'favorite_dishes': '평소에 좋아하는 음식',
    'cooking_skill': '요리 능력',
    'budget_per_meal_krw': '한 끼 예산',
    'food_adventurousness': '음식 모험 성향',
    'dietary_goals': '식이 목표',
    'allergens': '알레르기 재료',
    'foods_to_avoid': '피하고 싶은 재료',
    'health_note': '건강 관련 메모',
  };

  String _displayValue(MapEntry<String, Object> answer) {
    final value = answer.value;
    if (value is List<String>) return value.join(' · ');
    return switch (answer.key) {
      'age_years' => '$value세',
      'budget_per_meal_krw' => '$value원',
      'cooking_skill' || 'food_adventurousness' => '$value점 / 10점',
      _ => value.toString(),
    };
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: ConstrainedBox(
        constraints:
            BoxConstraints(maxHeight: MediaQuery.sizeOf(context).height * .72),
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(22, 0, 22, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisSize: MainAxisSize.min,
            children: [
              const MyPageSectionTitle('추천에 쓰이는 정보'),
              const SizedBox(height: 12),
              if (answers.isEmpty)
                const Text('아직 저장한 답변이 없어요. 추천 설문에서 취향과 식이 조건을 알려 주세요.'),
              for (final answer in answers.entries)
                Padding(
                  padding: const EdgeInsets.only(top: 7, bottom: 8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _labels[answer.key] ?? answer.key,
                        style: const TextStyle(
                            color: MyPageColors.muted, fontSize: 13),
                      ),
                      const SizedBox(height: 3),
                      Text(_displayValue(answer),
                          style: const TextStyle(fontSize: 16)),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
