// ChangeNotifier로 상태를 공유하는 방식 참고:
// prep-14.zip, lib/caia/action_store.dart (Week 9).
import 'package:flutter/foundation.dart';

import 'my_page_data.dart';
import 'my_page_repository.dart';

class MyPageController extends ChangeNotifier {
  MyPageController(this._repository);

  final MyPageRepository _repository;
  MyPageData? _data;
  Object? _loadError;
  bool _loading = false;
  bool _disposed = false;
  Future<void> _pendingWrites = Future<void>.value();

  MyPageData? get data => _data;
  Object? get loadError => _loadError;

  Future<void> load() async {
    if (_loading || _data != null || _disposed) return;
    _loading = true;
    _loadError = null;
    notifyListeners();
    try {
      _data = await _repository.load();
    } catch (error) {
      _loadError = error;
    } finally {
      _loading = false;
      if (!_disposed) notifyListeners();
    }
  }

  Future<void> saveProfile(UserProfile profile) {
    return _save(
        (current) => MyPageData(profile: profile, survey: current.survey));
  }

  Future<void> saveSurvey(FoodSurvey? survey) {
    final answer = survey == null || survey.isEmpty ? null : survey;
    return _save(
        (current) => MyPageData(profile: current.profile, survey: answer));
  }

  Future<void> _save(MyPageData Function(MyPageData current) update) {
    // 한 화면에서 저장 요청이 겹쳐도 가장 최근 저장값에 다음 변경을 적용합니다.
    final write = _pendingWrites.then((_) async {
      final current = _data;
      if (current == null || _disposed) {
        throw StateError('마이페이지를 먼저 불러와 주세요.');
      }
      final next = update(current);
      await _repository.save(next);
      _data = next;
      if (!_disposed) notifyListeners();
    });
    // 실패는 호출한 화면에 전달하며 다음 요청은 시도할 수 있게 합니다.
    _pendingWrites =
        write.then<void>((_) {}, onError: (Object _, StackTrace __) {});
    return write;
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }
}
