import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';
// 사진 선택 및 Android의 선택 결과 복구: https://pub.dev/packages/image_picker/versions/1.1.2
import 'package:image_picker/image_picker.dart';

Future<Uint8List?> pickProfilePhoto() async {
  final photo = await ImagePicker().pickImage(
    source: ImageSource.gallery,
    maxWidth: 1024,
    maxHeight: 1024,
    requestFullMetadata: false,
  );
  if (photo == null) return null;
  return _profilePhotoBytes(photo);
}

Future<Uint8List?> recoverProfilePhoto() async {
  if (kIsWeb || defaultTargetPlatform != TargetPlatform.android) return null;
  try {
    final lost = await ImagePicker().retrieveLostData();
    final photo = lost.files?.firstOrNull;
    return photo == null ? null : await _profilePhotoBytes(photo);
  } catch (_) {
    // 복구할 수 없는 선택은 기존 프로필 사진에 영향을 주지 않습니다.
    return null;
  }
}

Future<Uint8List> _profilePhotoBytes(XFile photo) async {
  const maxEdge = 320;
  final buffer = await ui.ImmutableBuffer.fromUint8List(
    await photo.readAsBytes(),
  );
  // 디코딩 크기 조정: https://api.flutter.dev/flutter/dart-ui/instantiateImageCodecWithSize.html
  final codec = await ui.instantiateImageCodecWithSize(
    buffer,
    getTargetSize: (width, height) {
      if (width >= height && width > maxEdge) {
        return const ui.TargetImageSize(width: maxEdge);
      }
      if (height > maxEdge) return const ui.TargetImageSize(height: maxEdge);
      return const ui.TargetImageSize();
    },
  );
  try {
    final frame = await codec.getNextFrame();
    try {
      final png = await frame.image.toByteData(format: ui.ImageByteFormat.png);
      if (png == null || png.lengthInBytes > 512 * 1024) {
        throw const FormatException('프로필 사진의 크기를 조정할 수 없습니다.');
      }
      return png.buffer
          .asUint8List(png.offsetInBytes, png.lengthInBytes)
          .asUnmodifiableView();
    } finally {
      frame.image.dispose();
    }
  } finally {
    codec.dispose();
  }
}
