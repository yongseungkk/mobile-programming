import 'dart:typed_data';

import 'package:flutter/material.dart';

class MyPageColors {
  static const background = Color(0xFFF9F5EE);
  static const card = Color(0xFFFFFDFA);
  static const line = Color(0xFFE9DFD2);
  static const ink = Color(0xFF2C211B);
  static const muted = Color(0xFF6D6057);
  static const accent = Color(0xFFAF4119);
  static const peach = Color(0xFFFAE8D9);
}

class MyPageAvatar extends StatelessWidget {
  const MyPageAvatar({super.key, required this.photoBytes, required this.size});

  final Uint8List? photoBytes;
  final double size;

  @override
  Widget build(BuildContext context) {
    final photo = photoBytes;
    final placeholder = Icon(
      Icons.person_rounded,
      size: size * .55,
      color: MyPageColors.muted,
    );
    return SizedBox.square(
      dimension: size,
      child: ClipOval(
        child: ColoredBox(
          color: MyPageColors.peach,
          child: ExcludeSemantics(
            child: photo == null
                ? placeholder
                : Image.memory(
                    photo,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => placeholder,
                  ),
          ),
        ),
      ),
    );
  }
}

class MyPagePanel extends StatelessWidget {
  const MyPagePanel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(18),
  });

  final Widget child;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: MyPageColors.card,
        borderRadius: BorderRadius.circular(19),
        border: Border.all(color: MyPageColors.line),
      ),
      child: Padding(padding: padding, child: child),
    );
  }
}

class MyPageSectionTitle extends StatelessWidget {
  const MyPageSectionTitle(this.text, {super.key});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      header: true,
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 17,
          fontWeight: FontWeight.w700,
          color: MyPageColors.ink,
          letterSpacing: -.35,
        ),
      ),
    );
  }
}

class MyPageEditor extends StatelessWidget {
  const MyPageEditor({
    super.key,
    required this.title,
    required this.body,
    required this.saveLabel,
    required this.saving,
    required this.onSave,
    this.error,
  });

  final String title;
  final Widget body;
  final String saveLabel;
  final bool saving;
  final VoidCallback? onSave;
  final String? error;

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !saving,
      child: Scaffold(
        backgroundColor: MyPageColors.background,
        appBar: AppBar(
          title: Text(title),
          backgroundColor: MyPageColors.background,
          foregroundColor: MyPageColors.ink,
          scrolledUnderElevation: 0,
          centerTitle: false,
          toolbarHeight: 60,
        ),
        body: SafeArea(
          top: false,
          child: Align(
            alignment: Alignment.topCenter,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 540),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(
                    child: SingleChildScrollView(
                      keyboardDismissBehavior:
                          ScrollViewKeyboardDismissBehavior.onDrag,
                      padding: const EdgeInsets.fromLTRB(20, 12, 20, 22),
                      child: body,
                    ),
                  ),
                  DecoratedBox(
                    decoration: const BoxDecoration(
                      color: MyPageColors.background,
                      border: Border(top: BorderSide(color: MyPageColors.line)),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(20, 12, 20, 14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          if (error != null)
                            Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: Semantics(
                                liveRegion: true,
                                child: Text(
                                  error!,
                                  style: TextStyle(
                                      color:
                                          Theme.of(context).colorScheme.error),
                                ),
                              ),
                            ),
                          FilledButton(
                            onPressed: saving ? null : onSave,
                            style: FilledButton.styleFrom(
                              minimumSize: const Size.fromHeight(50),
                              backgroundColor: MyPageColors.accent,
                              foregroundColor: Colors.white,
                            ),
                            child: Text(saving ? '저장 중…' : saveLabel),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
