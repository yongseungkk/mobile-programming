Future<String?> read(String key) => throw UnsupportedError('Native storage');

Future<void> write(String key, String value) =>
    throw UnsupportedError('Native storage');
