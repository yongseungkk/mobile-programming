import 'dart:io';

// 앱 데이터 디렉터리 경로: https://pub.dev/packages/path_provider/versions/2.1.5
import 'package:path_provider/path_provider.dart';

Future<File> _snapshot(String key) async {
  final directory = await getApplicationSupportDirectory();
  final name = 'my_page_${Uri.encodeComponent(key)}.json';
  return File('${directory.path}${Platform.pathSeparator}$name');
}

Future<String?> read(String key) async {
  final file = await _snapshot(key);
  if (!await file.exists()) return null;
  return file.readAsString();
}

Future<void> write(String key, String value) async {
  final file = await _snapshot(key);
  await file.parent.create(recursive: true);
  final staging = await file.parent.createTemp('.my-page-');
  try {
    // 사진, 설문, 프롬프트를 같은 파일로 한 번에 갱신합니다.
    final pending = File.fromUri(staging.uri.resolve('snapshot.json'));
    await pending.writeAsString(value, flush: true);
    await pending.rename(file.path);
  } finally {
    try {
      await staging.delete(recursive: true);
    } on FileSystemException {
      // 임시 폴더 정리 여부는 저장 성공에 영향을 주지 않습니다.
    }
  }
}
