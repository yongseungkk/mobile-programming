import 'package:flutter/material.dart';

import 'my_page_data.dart';
import 'my_page_widgets.dart';

class FoodSurveyScreen extends StatefulWidget {
  const FoodSurveyScreen(
      {super.key, required this.initial, required this.onSave});

  final FoodSurvey? initial;
  final Future<void> Function(FoodSurvey?) onSave;

  @override
  State<FoodSurveyScreen> createState() => _FoodSurveyScreenState();
}

class _FoodSurveyScreenState extends State<FoodSurveyScreen> {
  static final _listSeparator = RegExp(r'[,，\n]');
  static final _budgetFormat = RegExp(r'^(?:[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+)$');

  final _formKey = GlobalKey<FormState>();
  final _ageFieldKey = GlobalKey<FormFieldState<String>>();
  final _budgetFieldKey = GlobalKey<FormFieldState<String>>();
  late final TextEditingController _age;
  late final TextEditingController _favoriteDishes;
  late final TextEditingController _budget;
  late final TextEditingController _allergens;
  late final TextEditingController _foodsToAvoid;
  late final TextEditingController _healthNote;
  late final Set<Cuisine> _cuisines;
  late final Set<DietaryGoal> _goals;
  SurveyGender? _gender;
  int? _cookingSkill;
  int? _foodAdventurousness;
  bool _saving = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    final initial = widget.initial;
    _age = TextEditingController(text: initial?.ageYears?.toString());
    _gender = initial?.gender;
    _favoriteDishes =
        TextEditingController(text: initial?.favoriteDishes.join(', '));
    _budget =
        TextEditingController(text: initial?.budgetPerMealKrw?.toString());
    _cookingSkill = initial?.cookingSkill;
    _foodAdventurousness = initial?.foodAdventurousness;
    _allergens = TextEditingController(text: initial?.allergens.join(', '));
    _foodsToAvoid =
        TextEditingController(text: initial?.foodsToAvoid.join(', '));
    _healthNote = TextEditingController(text: initial?.healthNote);
    _cuisines = initial?.cuisines.toSet() ?? {};
    _goals = initial?.dietaryGoals.toSet() ?? {};
  }

  @override
  void dispose() {
    _age.dispose();
    _favoriteDishes.dispose();
    _budget.dispose();
    _allergens.dispose();
    _foodsToAvoid.dispose();
    _healthNote.dispose();
    super.dispose();
  }

  String? _validateAge(String? value) {
    final text = value?.trim() ?? '';
    if (text.isEmpty) return null;
    final age = int.tryParse(text, radix: 10);
    if (age == null || age < 0 || age > FoodSurvey.maxAgeYears) {
      return '0~${FoodSurvey.maxAgeYears} 사이의 정수를 입력해 주세요.';
    }
    return null;
  }

  int? _parseBudget(String value) =>
      int.tryParse(value.trim().replaceAll(',', ''), radix: 10);

  String? _validateBudget(String? value) {
    final text = value?.trim() ?? '';
    if (text.isEmpty) return null;
    if (!_budgetFormat.hasMatch(text) || _parseBudget(text) == null) {
      return '예산을 0 이상의 정수로 입력해 주세요.';
    }
    return null;
  }

  Future<void> _save() async {
    if (_saving) return;
    if (!_formKey.currentState!.validate()) {
      final invalidField = _ageFieldKey.currentState?.hasError == true
          ? _ageFieldKey
          : _budgetFieldKey;
      final fieldContext = invalidField.currentContext;
      if (fieldContext != null) {
        await Scrollable.ensureVisible(fieldContext, alignment: .15);
      }
      return;
    }
    final survey = FoodSurvey(
      ageYears: int.tryParse(_age.text.trim(), radix: 10),
      gender: _gender,
      cuisines: Cuisine.values.where(_cuisines.contains),
      favoriteDishes: _favoriteDishes.text.split(_listSeparator),
      cookingSkill: _cookingSkill,
      budgetPerMealKrw: _parseBudget(_budget.text),
      foodAdventurousness: _foodAdventurousness,
      dietaryGoals: DietaryGoal.values.where(_goals.contains),
      allergens: _allergens.text.split(_listSeparator),
      foodsToAvoid: _foodsToAvoid.text.split(_listSeparator),
      healthNote: _healthNote.text,
    );
    if (survey.isEmpty && widget.initial == null) {
      setState(() => _error = '한 가지 이상 응답해 주세요.');
      return;
    }
    await _persist(
      survey.isEmpty ? null : survey,
      survey.isEmpty ? '저장한 설문을 지웠어요.' : '추천 설문을 저장했어요.',
    );
  }

  Future<void> _clear() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('저장한 설문을 지울까요?'),
        content: const Text('나중에 마이페이지에서 다시 작성할 수 있어요.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('취소'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('지우기'),
          ),
        ],
      ),
    );
    if (confirmed == true && mounted) {
      await _persist(null, '저장한 설문을 지웠어요.');
    }
  }

  Future<void> _persist(FoodSurvey? survey, String message) async {
    if (_saving) return;
    FocusScope.of(context).unfocus();
    setState(() {
      _saving = true;
      _error = null;
    });
    try {
      await widget.onSave(survey);
      if (mounted) Navigator.of(context).pop(message);
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _saving = false;
        _error = '설문을 저장하지 못했어요. 다시 시도해 주세요.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    const supportingStyle = TextStyle(
      fontSize: 14,
      height: 1.45,
      color: MyPageColors.muted,
    );

    return MyPageEditor(
      title: '추천 설문',
      saveLabel: '설문 저장',
      saving: _saving,
      error: _error,
      onSave: _save,
      body: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            DecoratedBox(
              decoration: BoxDecoration(
                color: MyPageColors.peach,
                borderRadius: BorderRadius.circular(19),
              ),
              child: const Padding(
                padding: EdgeInsets.all(17),
                child: Row(
                  children: [
                    Icon(Icons.soup_kitchen_outlined,
                        color: MyPageColors.accent),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        '원하는 항목에만 답해 주세요. 저장한 답변은 메뉴 추천을 요청할 때 사용돼요.',
                        style: supportingStyle,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),
            MyPagePanel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const MyPageSectionTitle('기본 정보'),
                  const SizedBox(height: 14),
                  TextFormField(
                    key: _ageFieldKey,
                    controller: _age,
                    enabled: !_saving,
                    keyboardType: TextInputType.number,
                    textInputAction: TextInputAction.done,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    decoration: const InputDecoration(
                      labelText: '만 나이',
                      hintText: '예: 22',
                      suffixText: '세',
                    ),
                    validator: _validateAge,
                  ),
                  const SizedBox(height: 14),
                  const Text('성별', style: supportingStyle),
                  const SizedBox(height: 4),
                  Wrap(
                    spacing: 7,
                    children: [
                      for (final gender in SurveyGender.values)
                        ChoiceChip(
                          label: Text(gender.label),
                          selected: _gender == gender,
                          onSelected: _saving
                              ? null
                              : (selected) => setState(
                                    () => _gender = selected ? gender : null,
                                  ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            MyPagePanel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const MyPageSectionTitle('선호하는 음식 종류'),
                  const SizedBox(height: 4),
                  const Text('여러 개 선택할 수 있어요.', style: supportingStyle),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 7,
                    runSpacing: 3,
                    children: [
                      for (final cuisine in Cuisine.values)
                        FilterChip(
                          label: Text(cuisine.label),
                          selected: _cuisines.contains(cuisine),
                          onSelected: _saving
                              ? null
                              : (selected) => setState(() {
                                    if (selected) {
                                      _cuisines.add(cuisine);
                                    } else {
                                      _cuisines.remove(cuisine);
                                    }
                                  }),
                        ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  TextFormField(
                    controller: _favoriteDishes,
                    enabled: !_saving,
                    maxLength: 140,
                    decoration: const InputDecoration(
                      labelText: '평소에 좋아하는 음식',
                      hintText: '예: 제육볶음, 돈가스, 마라탕',
                      helperText: '메뉴 이름을 쉼표로 구분해 주세요.',
                      helperMaxLines: 2,
                    ),
                  ),
                  const SizedBox(height: 11),
                  _ScoreField(
                    key: const ValueKey('food-adventurousness'),
                    label: '음식 모험 성향',
                    description: '1점은 대중적인 메뉴, 10점은 특이한 재료나 의외의 조합도 좋아해요.',
                    value: _foodAdventurousness,
                    onChanged: _saving
                        ? null
                        : (value) =>
                            setState(() => _foodAdventurousness = value),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            MyPagePanel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const MyPageSectionTitle('예산과 조리'),
                  const SizedBox(height: 14),
                  TextFormField(
                    key: _budgetFieldKey,
                    controller: _budget,
                    enabled: !_saving,
                    keyboardType: TextInputType.number,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    decoration: const InputDecoration(
                      labelText: '한 끼 예산',
                      hintText: '예: 8000',
                      suffixText: '원',
                      helperText: '한 끼에 쓸 수 있는 최대 금액이에요.',
                      helperMaxLines: 2,
                    ),
                    validator: _validateBudget,
                  ),
                  const SizedBox(height: 14),
                  _ScoreField(
                    key: const ValueKey('cooking-skill'),
                    label: '요리 능력',
                    description: '1점은 간단한 조리도 어려워요. 10점은 복잡한 요리도 혼자 할 수 있어요.',
                    value: _cookingSkill,
                    onChanged: _saving
                        ? null
                        : (value) => setState(() => _cookingSkill = value),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            MyPagePanel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const MyPageSectionTitle('건강과 식이 조건'),
                  const SizedBox(height: 4),
                  const Text('식사에서 신경 쓰는 부분을 골라 주세요.', style: supportingStyle),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 7,
                    runSpacing: 3,
                    children: [
                      for (final goal in DietaryGoal.values)
                        FilterChip(
                          label: Text(goal.label),
                          selected: _goals.contains(goal),
                          onSelected: _saving
                              ? null
                              : (selected) => setState(() {
                                    if (selected) {
                                      _goals.add(goal);
                                    } else {
                                      _goals.remove(goal);
                                    }
                                  }),
                        ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  TextFormField(
                    controller: _allergens,
                    enabled: !_saving,
                    maxLength: 100,
                    decoration: const InputDecoration(
                      labelText: '알레르기 재료',
                      hintText: '예: 땅콩, 새우',
                      helperText: '여러 재료는 쉼표로 구분해 주세요.',
                      helperMaxLines: 2,
                    ),
                  ),
                  const SizedBox(height: 11),
                  TextFormField(
                    controller: _foodsToAvoid,
                    enabled: !_saving,
                    maxLength: 100,
                    decoration: const InputDecoration(
                      labelText: '피하고 싶은 재료',
                      hintText: '예: 고수, 가지',
                    ),
                  ),
                  const SizedBox(height: 11),
                  TextFormField(
                    controller: _healthNote,
                    enabled: !_saving,
                    minLines: 2,
                    maxLines: 3,
                    maxLength: 140,
                    decoration: const InputDecoration(
                      labelText: '건강 관련 메모',
                      hintText: '예: 매운 음식은 속이 불편해요.',
                      helperText: '추천에 반영할 식사 조건만 적어 주세요.',
                      helperMaxLines: 2,
                    ),
                  ),
                ],
              ),
            ),
            if (widget.initial != null) ...[
              const SizedBox(height: 12),
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton.icon(
                  onPressed: _saving ? null : _clear,
                  icon: const Icon(Icons.delete_outline_rounded),
                  label: const Text('설문 지우기'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _ScoreField extends StatelessWidget {
  const _ScoreField({
    super.key,
    required this.label,
    required this.description,
    required this.value,
    required this.onChanged,
  });

  final String label;
  final String description;
  final int? value;
  final ValueChanged<int?>? onChanged;

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<int>(
      value: value,
      isExpanded: true,
      decoration: InputDecoration(
        labelText: label,
        helperText: description,
        helperMaxLines: 3,
      ),
      items: [
        const DropdownMenuItem(child: Text('응답 안 함')),
        for (var score = FoodSurvey.minScore;
            score <= FoodSurvey.maxScore;
            score++)
          DropdownMenuItem(value: score, child: Text('$score점')),
      ],
      onChanged: onChanged,
    );
  }
}
